from .troop_tips_pb2 import *
