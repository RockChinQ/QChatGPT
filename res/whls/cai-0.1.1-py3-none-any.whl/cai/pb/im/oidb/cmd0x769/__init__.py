from .cmd0x769_pb2 import *
