from .cmd0xd50_pb2 import *
