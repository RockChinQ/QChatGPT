from rtea import qqtea_encrypt, qqtea_decrypt  # noqa
